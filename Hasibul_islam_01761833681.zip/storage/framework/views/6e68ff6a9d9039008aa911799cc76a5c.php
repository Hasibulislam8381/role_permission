<!-- resources/views/backend/subcategory/edit.blade.php -->

<?php $__env->startSection('title', 'Edit Subcategory'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <h2>Edit Subcategory</h2>
        
        <!-- Display validation errors, if any -->
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <!-- Edit Subcategory Form -->
        <form action="<?php echo e(route('backend.subcategory.update', $subcategory->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="mb-3">
                <label for="name" class="form-label">Subcategory Name:</label>
                <input type="text" name="name" id="name" class="form-control" value="<?php echo e(old('name', $subcategory->name)); ?>" required>
            </div>
            <div class="mb-3">
                <label for="category_id" class="form-label">Select Category:</label>
                <select name="category_id" id="category_id" class="form-control" required>
                    <option value="">Select a Category</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php echo e($category->id == $subcategory->category_id ? 'selected' : ''); ?>>
                            <?php echo e($category->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bangla_puzzle\resources\views/backend/subcategory/edit.blade.php ENDPATH**/ ?>