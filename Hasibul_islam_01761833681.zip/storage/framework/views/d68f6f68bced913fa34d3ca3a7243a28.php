<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Product Details</title>
    <link rel="stylesheet" href="<?php echo e(asset('backend/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/style.css')); ?>">
    <style>
        /* Custom styles for related product images */
        .card-img-top {
            height: 150px; /* Set a fixed height */
            object-fit: cover; /* Cover the area while maintaining aspect ratio */
        }
    </style>
</head>
<body>
    <div class="container py-5">
        <div class="mb-5 text-center">
            <a href="<?php echo e(url('/')); ?>">
                <button class="btn btn-secondary dropdown-toggle">
                    All Products
                </button>
            </a>
        </div>
        <div class="row">
            <!-- Product Image -->
            <div class="col-md-6">
                <div class="product-image-single">
                    <img src="<?php echo e(asset('storage/' . $product->image)); ?>" class="img-fluid" alt="<?php echo e($product->name); ?>">
                </div>
            </div>
            
            <!-- Product Details -->
            <div class="col-md-6">
                <h1><?php echo e($product->name); ?></h1>
                <p class="text-muted">Category: <?php echo e($product->subcategory->name); ?></p>
                
                <div class="pricing">
                    <?php if($product->old_price): ?>
                    <span class="text-danger fw-bold me-2">$<?php echo e($product->new_price); ?></span>
                    <span class="text-muted text-decoration-line-through">$<?php echo e($product->old_price); ?></span>
                    <?php else: ?>
                    <span class="text-danger fw-bold">$<?php echo e($product->new_price); ?></span>
                    <?php endif; ?>
                </div>
                
                <p class="mt-4">
                    <?php echo e($product->description); ?>

                </p>
    
                <form action="" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="quantity">Quantity:</label>
                        <input type="number" name="quantity" id="quantity" class="form-control w-25" value="1" min="1">
                    </div>
    
                    <button type="submit" class="btn btn-primary mt-3">
                        <i class="fa fa-shopping-cart"></i> Add to Cart
                    </button>
                </form>
            </div>
        </div>
    
        <!-- Related Products -->
        <div class="row mt-5">
            <div class="col-12">
                <h2 class="mb-4">Related Products</h2>
            </div>
    
            <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3">
                <div class="card mb-4">
                    <img src="<?php echo e(asset('storage/' . $related->image)); ?>" class="card-img-top" alt="<?php echo e($related->name); ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($related->name); ?></h5>
                        <p class="card-text text-danger">$<?php echo e($related->new_price); ?></p>
                        <a href="<?php echo e(route('product_details', $related->slug)); ?>" class="btn btn-outline-primary btn-sm">View Details</a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>  
</body>
</html>
<?php /**PATH C:\laragon\www\bangla_puzzle\resources\views/frontend/product_details.blade.php ENDPATH**/ ?>