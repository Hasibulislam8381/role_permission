<?php $__env->startSection('title', 'Edit Category'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid page__heading-container">
        <div class="page__heading d-flex align-items-end">
            <div class="flex">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Category Edit</li>
                    </ol>
                </nav>
                <h1 class="m-0">Edit</h1>
            </div>
        </div>
    </div>
    <section>
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="card">
                        <div class="card-header">
                            <h1 class="text-center">Edit Category</h1>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('backend.category.update', $category->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="mb-3">
                                    <label for="name" class="form-label">Category Name:</label>
                                    <input type="text" name="name" id="name" class="form-control" value="<?php echo e(old('name', $category->name)); ?>" required>
                                </div>
                                <button type="submit" class="btn btn-primary">Update</button>
                                <a href="<?php echo e(route('backend.category.index')); ?>" class="btn btn-secondary">Cancel</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bangla_puzzle\resources\views/backend/category/edit.blade.php ENDPATH**/ ?>