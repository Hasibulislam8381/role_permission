
<?php $__env->startSection('title', 'Edit Product'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <h2>Edit Product</h2>

        <form action="<?php echo e(route('backend.product.update', $product->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            
            <!-- Product Name -->
            <div class="mb-3">
                <label for="name" class="form-label">Product Name:</label>
                <input type="text" name="name" id="name" class="form-control" value="<?php echo e($product->name); ?>" required>
            </div>

            <div class="mb-3">
               
                <label for="subcategory_id" class="form-label">Category:</label>
                <select name="category_id" id="category_id" class="form-select" required>
                    <option value="">Select a Category</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php echo e($category->id == $product->category_id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                
                <select name="subcategory_id" id="subcategory_id" class="form-select mt-3" required>
                    <option value="">Select a Subcategory</option>
                </select>
                
            
                <div id="subcategories-data" style="display: none;">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div data-category-id="<?php echo e($category->id); ?>">
                            <?php $__currentLoopData = $category->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span data-subcategory-id="<?php echo e($subcategory->id); ?>" ><?php echo e($subcategory->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
            </div> 
             <!-- Current Product Image -->
             <div class="mb-3">
                <label for="image" class="form-label">Current Image:</label>
                <div>
                    <?php if($product->image): ?>
                        <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>" style="max-width: 100px; max-height: 100px;" class="img-thumbnail">
                    <?php else: ?>
                        <p>No image available</p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- New Image Upload -->
            <div class="mb-3">
                <label for="image" class="form-label">Upload New Image:</label>
                <input type="file" name="image" id="image" class="form-control" accept="image/*">
            </div>

            <!-- Other fields like description, price, etc. -->
            <div class="mb-3">
                <label for="description" class="form-label">Description:</label>
                <textarea name="description" id="description" class="form-control"><?php echo e($product->description); ?></textarea>
            </div>
            <div class="mb-3">
                <label for="old_price" class="form-label">Old Price:</label>
                <input type="number" name="old_price" id="old_price" class="form-control" value="<?php echo e($product->old_price); ?>" step="0.01">
            </div>
            <div class="mb-3">
                <label for="new_price" class="form-label">New Price:</label>
                <input type="number" step="0.01" name="new_price" id="new_price" class="form-control" value="<?php echo e($product->new_price); ?>" required>
            </div>

            <!-- Submit Button -->
            <button type="submit" class="btn btn-primary">Update Product</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $(document).ready(function() {
        
$('#category_id').on('change', function() {
    var categoryId = $(this).val();

    // Clear the subcategory dropdown first
    $('#subcategory_id').html('<option value="">Select a Subcategory</option>');

    if (categoryId) {
        // Find the related subcategories using the hidden data
        $('#subcategories-data div').each(function() {
            var dataCategoryId = $(this).data('category-id');

            if (categoryId == dataCategoryId) {
                // Loop through the subcategories and append them to the dropdown
                $(this).find('span').each(function() {
                    var subcategoryId = $(this).data('subcategory-id');
                    var subcategoryName = $(this).text();

                    $('#subcategory_id').append('<option value="' + subcategoryId + '">' + subcategoryName + '</option>');
                });
            }
        });
    }
});
});

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bangla_puzzle\resources\views/backend/product/edit.blade.php ENDPATH**/ ?>