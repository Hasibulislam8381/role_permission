<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <div class="section_background">
        <h2 class="text-center">Welcome to the Paradise</h2>


       
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bangla_puzzle\resources\views/backend/index.blade.php ENDPATH**/ ?>