<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Products</title>
    <link rel="stylesheet" href="<?php echo e(asset('backend/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/style.css')); ?>">
    <style>
        /* Add custom styles for the dropdown */
        .subcategory-dropdown {
            display: none;
            position: absolute;
            background-color: white;
            border: 1px solid #ccc;
            z-index: 1;
        }
        
        .category-item:hover .subcategory-dropdown {
            display: block;
        }
    </style>
</head>
<body>
    <div class="note container">[admin url:http://127.0.0.1:8000/admin
        <div>email: admin@gmail.com </div>
        <div>password: admin123 </div>
        <div>Please update the composer for Toastr] </div>
    </div>
    <div class="container">
        <h1 class="my-4">Product List</h1>

        <div class="mb-4">
            <h4>Categories</h4>
            <div class="d-inline-block position-relative">
                <button class="btn btn-secondary dropdown-toggle" id="categoryDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                    Select Category
                </button>
                <a href="<?php echo e(url('/')); ?>">
                    <button class="btn btn-secondary dropdown-toggle">
                        All Products
                    </button>
                </a>
                
                <ul class="dropdown-menu" aria-labelledby="categoryDropdown">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="category-item">
                            <a class="dropdown-item" href="#"><?php echo e($category->name); ?></a>
                            <div class="subcategory-dropdown">
                                <ul class="list-unstyled">
                                    <?php $__currentLoopData = $category->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a class="dropdown-item subcategory-link" href="<?php echo e(route('products.filter', $subcategory->slug)); ?>"><?php echo e($subcategory->name); ?></a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>

        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h2 class="my-4"><?php echo e($category->name); ?></h2> <!-- Display Category Name -->
            <div class="row">
                <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <!-- Iterate over products for each category -->
               
                    <div class="col-md-3 mb-4">
                        <a href="<?php echo e(route('product_details',$product->slug)); ?>">
                        <div class="card">
                            <?php if($product->image): ?>
                                <img src="<?php echo e(asset('storage/' . $product->image)); ?>" class="card-img-top product-image" alt="<?php echo e($product->name); ?>">
                            <?php else: ?>
                                <img src="https://via.placeholder.com/150" class="card-img-top product-image" alt="Default Image">
                            <?php endif; ?>
                            
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($product->name); ?></h5>
                                <p class="card-text">
                                    <?php if($product->old_price): ?>
                                        <del>$<?php echo e($product->old_price); ?></del>
                                    <?php endif; ?>
                                    <strong>$<?php echo e($product->new_price); ?></strong>
                                </p>
                                <p class="card-text"><?php echo e($product->description ?? 'No description available'); ?></p>
                                <a href="#" class="btn btn-primary">View Details</a>
                            </div>
                        </div>
                       </a>
                    </div>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <script src="<?php echo e(asset('backend/js/bootstrap.bundle.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\laragon\www\bangla_puzzle\resources\views/frontend/index.blade.php ENDPATH**/ ?>