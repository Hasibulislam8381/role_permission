@extends('layouts.backend.master')
@section('title', 'Dashboard')
@section('content')
    <div class="section_background">
        <h2 class="text-center">Welcome to the Paradise</h2>


       
    </div>


@endsection
