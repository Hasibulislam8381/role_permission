<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::table('products', function (Blueprint $table) {
            // Adding category_id as a foreign key that references the categories table
            $table->unsignedBigInteger('category_id')->after('id'); // or after any other column
            $table->foreign('category_id')->references('id')->on('categories')->onDelete('cascade');
        });
    }
    
    public function down()
    {
        Schema::table('products', function (Blueprint $table) {
            // Dropping the foreign key and the column when rolling back
            $table->dropForeign(['category_id']);
            $table->dropColumn('category_id');
        });
    }
    
};
